echo -e "\e[36m░█████╗░██╗░░░██╗░█████╗░██╗░░██╗░█████╗░\e[0m"
echo -e "\e[36m██╔══██╗╚██╗░██╔╝██╔══██╗██║░██╔╝██╔══██╗\e[0m"
echo -e "\e[36m███████║░╚████╔╝░███████║█████═╝░███████║\e[0m"
echo -e "\e[36m██╔══██║░░╚██╔╝░░██╔══██║██╔═██╗░██╔══██║\e[0m"
echo -e "\e[36m██║░░██║░░░██║░░░██║░░██║██║░╚██╗██║░░██║\e[0m"
echo -e "\e[36m╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝\e[0m"

echo -e "\n\e[33mMemulai instalasi...\e[0m"

# Install dependencies
npm install

echo -e "\n\e[32mInstalasi selesai! Kamu sekarang bisa menjalankan bot kamu dengan menjalankan perintah 'node viki.js'.\e[0m"

# Run bot
node viki.js